package org.baeldung.security;

import java.util.Collection;

import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.GrantedAuthority;

public class ExpiringUsernamePasswordAuthenticationToken extends UsernamePasswordAuthenticationToken {

	public ExpiringUsernamePasswordAuthenticationToken(Object principal, Object credentials,
			Collection<? extends GrantedAuthority> authorities) {
		super(principal, credentials, authorities);
	}
	
	@Override
	public boolean isAuthenticated() {
		OpenIdConnectUserDetails user = (OpenIdConnectUserDetails) getPrincipal();
		return !user.getToken().isExpired();
	}

}
